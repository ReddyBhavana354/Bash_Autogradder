#!/bin/bash
mkdir organised
cd mock_grading
while read line;	
do cd ../organised
mkdir "$line"
cd ../mock_grading/submissions
for f in $(find . -name "*$line*")
do
path=$(realpath $f)
cd ../../organised
cd "$line"
ln -s $path $f
cd ../../mock_grading/submissions
done
cd ..	
done < roll_list


 

