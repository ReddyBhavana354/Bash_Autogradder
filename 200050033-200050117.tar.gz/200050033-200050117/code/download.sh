#!/bin/bash
if [ $# = 2 ]
then
	mkdir mock_grading
	cd mock_grading
	wget -r -np -nH --cut-dirs=$(($2+1)) -R index.html.tmp -R index.html $1
else
	echo "Usage: bash download.sh <link to directory> <cut-dirs argument>"
	exit 1
fi
