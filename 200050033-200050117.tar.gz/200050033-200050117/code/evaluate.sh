#!/bin/bash
> marksheet.csv
> distribution.txt
cd mock_grading/inputs
for a in $(find . -name  "*.in*")
do
path=$(realpath $a)
var="$a"
var=${var%.in}
cd ..
	while read line;
	do cd ../organised
	cd "$line"
	mkdir student_outputs 2>/dev/null
	cd student_outputs
        >"$var".out
	path1=$(realpath "$var".out)
	cd ..
	g++ $(find . -name "*.cpp*") -o executable 2>/dev/null
	{ timeout 10s ./executable < $path >$path1 2>/dev/null; } 2> out_err
	rm out_err
	cd ../../mock_grading
	done < roll_list
	cd inputs
done
cd ..
while read line;
do cd outputs
count=0
	for l in $(find . -name "*.out*")
	do
		name="$l"
		name=${name%.out}
		prefix="./"
		name=${name#$prefix}
			diff -q $l  ../../organised/"$line"/student_outputs/$l 1>/dev/null
			val=$?
			if [ $val -eq 0 ]
			then
				
				((count++))
			else
				((count))
			
			fi

	done
cd ../..
echo "$line,$count" >> marksheet.csv
echo "$count" >> distribution.txt
sort -nr distribution.txt -o distribution.txt
cd mock_grading
done < roll_list
